Supporting files for the manuscript “Imputing Missing Values with External Data” 
Authors: Thiesmeier R, Bottai M, Orsini N. 
Date: October 1, 2024

1. Manuscript in pdf format

2. Folder 1: mi_impute_from
All files (ado and sthlp) for the Stata command mi_impute_from and mi_impute_from_get. 
The command can be downloaded from the SSC Archive typing: ssc install mi_impute_from 

3. Folder 2: Examples
The folder contains three sub-folders, each for one of the three examples that are described in the manuscript. 
- do-files to execute the examples (example1.do, example2.do, example3.do) 
- txt-files with the log-files from the executed examples (used in the manuscript)
- Datasets in .dta format created in the do-files (study_1.dta, study_2.dta, etc.)
- txt-files containing the regression coefficients and covariance matrices from the example (b_study1.txt, v_study1.txt, etc.)
Example 3 contains a figure in .png format (Figure 1 in the manuscript) (figure1.png).